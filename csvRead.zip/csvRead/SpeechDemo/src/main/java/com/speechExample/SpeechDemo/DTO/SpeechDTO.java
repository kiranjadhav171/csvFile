package com.speechExample.SpeechDemo.DTO;

public class SpeechDTO {

	private String speaker;
	private String topic;
	private String date;
	private int words;
	public String getSpeaker() {
		return speaker;
	}
	public void setSpeaker(String speaker) {
		this.speaker = speaker;
	}
	public String getTopic() {
		return topic;
	}
	public void setTopic(String topic) {
		this.topic = topic;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public int getWords() {
		return words;
	}
	public void setWords(int words) {
		this.words = words;
	}
	@Override
	public String toString() {
		return "SpeechDTO [speaker=" + speaker + ", topic=" + topic + ", date=" + date + ", words=" + words + "]";
	}
	
	
	
	

	
}
