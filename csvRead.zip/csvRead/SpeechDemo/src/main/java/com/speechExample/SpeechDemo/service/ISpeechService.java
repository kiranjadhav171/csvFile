package com.speechExample.SpeechDemo.service;

public interface ISpeechService {

	void readCSV();
	public String leastWordy();
	public String mostSecurity(String topic);
	String speachesIn2013(String yearspeaker);
}
