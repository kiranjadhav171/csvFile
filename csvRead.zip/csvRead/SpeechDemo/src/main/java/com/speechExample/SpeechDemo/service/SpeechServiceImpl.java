package com.speechExample.SpeechDemo.service;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import com.speechExample.SpeechDemo.dao.ISpeechDao;
import com.speechExample.SpeechDemo.domain.SpeechDomain;

@Service
public class SpeechServiceImpl implements ISpeechService {

	@Autowired
	ISpeechDao speechDao;
	
	@Autowired
	JdbcTemplate jtm;
	
	@Override
	public void readCSV() {
		try
		{
		ArrayList<SpeechDomain> ar = new ArrayList<SpeechDomain>();
		File csvFile = new File("C:\\Users\\Kiran Jadhav\\Documents\\csvRead\\csvDemo.csv");
		BufferedReader br = new BufferedReader(new FileReader(csvFile));
		//String line = "";
		String splitBy = ",";
		
		String line = br.readLine();
		while ((line = br.readLine()) !=null) {
	         Object[] b = line.split(splitBy);
	       // for(int i = 1; i<b.length;i++) {
	        	SpeechDomain s1 = new SpeechDomain();
	        	s1.setSpeaker(String.valueOf(b[0]));
	        	s1.setTopic(String.valueOf(b[1]));
	        	s1.setDate(String.valueOf(b[2]));
	        	s1.setWords(Integer.valueOf((String)b[3]));
	        	 ar.add(s1);
	        //}
	       
	    }
		speechDao.saveAll(ar);
		//System.out.println(ar);
	    br.close();
		}
		catch(IOException ex) {
		ex.printStackTrace();
		}
		finally{
		//System.out.println("thank you");
		}

		
	}

	@Override
	public String leastWordy() {
		// TODO Auto-generated method stub
		String sql = "SELECT speaker FROM SPEECH_DOMAIN group by speaker order by sum(words)  limit 1";
		return jtm.queryForObject(sql,String.class);
	}

	@Override
	public String mostSecurity(String topic) {
		String sql = "SELECT speaker FROM SPEECH_DOMAIN where topic=? group by speaker order by sum(words)  limit 1";
		return jtm.queryForObject(sql, new Object[]{topic}, String.class);
	}

	@Override
	public String speachesIn2013(String yearspeaker) {
		// TODO Auto-generated method stub
		try {
		String sql = "SELECT speaker FROM SPEECH_DOMAIN where year(date)=? group by speaker order by sum(words) desc limit 1";
		
		return	jtm.queryForObject(sql, new Object[]{yearspeaker}, String.class);
		} catch(Exception e) {
	        return null;
	    }
		
	}
	

}
