package com.speechExample.SpeechDemo;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.speechExample.SpeechDemo.DTO.SpeechResponseDTO;
import com.speechExample.SpeechDemo.service.ISpeechService;
import com.speechExample.SpeechDemo.utility.CommonUtils;
import com.speechExample.SpeechDemo.utility.HttpStatusCodes;
import com.speechExample.SpeechDemo.utility.ResponseMessageDTO;

@Controller
public class SpeechController {

	@Autowired
	ISpeechService speechService;
	
	@RequestMapping(value = "/evaluate", headers = "Accept=application/json")
    @ResponseBody
    public ResponseMessageDTO getList(@RequestParam(value="url1", required = false) String url1,
    		@RequestParam(value = "url2", required = false) String url2) throws IOException{
		
		if(url1!=null) {
		InputStream inputStream = new URL(url1).openStream();
		
		//download file from url and copy it to local system
		Files.copy(inputStream, Paths.get("C:\\Users\\Kiran Jadhav\\Documents\\csvRead\\csvDemo.csv"), StandardCopyOption.REPLACE_EXISTING);
		speechService.readCSV();
		}
		
		if(url2!=null) {
			InputStream inputStream = new URL(url2).openStream();
			
			//download file from url and copy it to local system
			//Files.copy(inputStream, Paths.get("C:\\var\\cdi\\cota\\bny\\feed\\csvDemo.csv"), StandardCopyOption.REPLACE_EXISTING);
			speechService.readCSV();	
		}
		
		if(url1==null & url2==null) {
			return CommonUtils.getErrorMessage(HttpStatusCodes.ERROR.getCode(), "URL not available");
		}
		
		String leastWordy = speechService.leastWordy();
		String mostSecurity = speechService.mostSecurity("homeland security");
		String mostSpeeches = speechService.speachesIn2013("2013");
		SpeechResponseDTO dto = new SpeechResponseDTO();
		dto.setLeastWordy(leastWordy);
		dto.setMostSecurity(mostSecurity);
		dto.setMostSpeeches(mostSpeeches);
		
		//String speechesIn = speechService.mostSpeaches();
		
		//dto.setMostSpeeches(mostSpeeches);
		
		return CommonUtils.getSuccessMessage(HttpStatusCodes.SUCCESS.getCode(),
				dto);
		
	}
	
}
