package com.speechExample.SpeechDemo.utility;

public class CommonUtils {

	public static ResponseMessageDTO getSuccessMessage(String responseMessage,Object data){
		ResponseMessageDTO response = new ResponseMessageDTO();
		response.setResponseCode(HttpStatusCodes.SUCCESS.getCode());
		response.setResponseMessage(responseMessage);
		response.setData(data);
		
		return response;
	}
	
	public static ResponseMessageDTO getErrorMessage(String responseMessage,Object data){
		ResponseMessageDTO response = new ResponseMessageDTO();
		response.setResponseCode(HttpStatusCodes.ERROR.getCode());
		response.setResponseMessage(responseMessage);
		response.setData(data);
		
		return response;
	}
}
