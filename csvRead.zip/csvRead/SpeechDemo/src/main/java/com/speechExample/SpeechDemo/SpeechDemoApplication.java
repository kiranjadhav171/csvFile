package com.speechExample.SpeechDemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpeechDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpeechDemoApplication.class, args);
	}

}
