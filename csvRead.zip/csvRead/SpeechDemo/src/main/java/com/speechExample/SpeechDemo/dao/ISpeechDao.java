package com.speechExample.SpeechDemo.dao;

import java.util.ArrayList;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.speechExample.SpeechDemo.DTO.SpeechDTO;
import com.speechExample.SpeechDemo.domain.SpeechDomain;

@Repository
public interface ISpeechDao extends JpaRepository<SpeechDomain,Long>{
	

}
