package com.speechExample.SpeechDemo.DTO;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonRootName;

@XmlRootElement(name = "SpeechResponseDTO")
@JsonRootName(value = "SpeechResponseDTO")
public class SpeechResponseDTO {
	
	@JsonProperty(value = "mostSpeeches")
	@XmlElement(name = "mostSpeeches")
	String mostSpeeches;
	
	@JsonProperty(value = "mostSecurity")
	@XmlElement(name = "mostSecurity")
	String mostSecurity;
	
	@JsonProperty(value = "leastWordy")
	@XmlElement(name = "leastWordy")
	String leastWordy;

	public String getMostSpeeches() {
		return mostSpeeches;
	}

	public void setMostSpeeches(String mostSpeeches) {
		this.mostSpeeches = mostSpeeches;
	}

	public String getMostSecurity() {
		return mostSecurity;
	}

	public void setMostSecurity(String mostSecurity) {
		this.mostSecurity = mostSecurity;
	}

	public String getLeastWordy() {
		return leastWordy;
	}

	public void setLeastWordy(String leastWordy) {
		this.leastWordy = leastWordy;
	}
	
	
	

}
