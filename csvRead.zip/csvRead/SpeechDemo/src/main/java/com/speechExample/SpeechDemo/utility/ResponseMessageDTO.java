package com.speechExample.SpeechDemo.utility;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonRootName;


@XmlRootElement(name = "Response")
@JsonRootName(value = "Response")
@JsonInclude(Include.NON_NULL)

public class ResponseMessageDTO {

	@XmlElement(name = "ResponseCode")
	@JsonProperty(value = "ResponseCode")
	private String responseCode;

	@XmlElement(name = "ResponseMessage")
	@JsonProperty(value = "ResponseMessage")
	private String responseMessage;

	@XmlElement(name = "Data")
	@JsonProperty(value = "Data")
	private Object data;

	public String getResponseCode() {
		return responseCode;
	}

	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}

	public String getResponseMessage() {
		return responseMessage;
	}

	public void setResponseMessage(String responseMessage) {
		this.responseMessage = responseMessage;
	}

	public Object getData() {
		return data;
	}

	public void setData(Object data) {
		this.data = data;
	}
	
	
}
