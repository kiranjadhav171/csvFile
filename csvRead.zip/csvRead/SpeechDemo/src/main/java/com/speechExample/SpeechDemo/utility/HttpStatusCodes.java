package com.speechExample.SpeechDemo.utility;

public enum HttpStatusCodes {
	SUCCESS("200"),
	ERROR("300"),
	;

	

	private String code;
	/**
	 * @param code
	 */
	private HttpStatusCodes(String code) {
		this.code=code;
	}
	/**
	 * This is used return status code
	 * @return code
	 */
	public String getCode() {
		return code;
	}
}
